@extends('master')
@section('title', 'View a ticket')
@section('content')
<style>
    body {
        font-family: Arial;
    }
    
    .comment-form-container {
        background: #F0F0F0;
        border: #e0dfdf 1px solid;
        padding: 20px;
        border-radius: 2px;
    }
    
    .input-row {
        margin-bottom: 20px;
    }
    
    .input-field {
        width: 100%;
        border-radius: 2px;
        padding: 10px;
        border: #e0dfdf 1px solid;
    }
    
    .btn-submit {
        padding: 10px 20px;
        background: #333;
        border: #1d1d1d 1px solid;
        color: #f0f0f0;
        font-size: 0.9em;
        width: 100px;
        border-radius: 2px;
        cursor:pointer;
    }
    
    ul {
        list-style-type: none;
    }
    
    .comment-row {
        border-bottom: #e0dfdf 1px solid;
        margin-bottom: 15px;
        padding: 15px;
    }
    
    .outer-comment {
        background: #F0F0F0;
        padding: 20px;
        border: #dedddd 1px solid;
    }
    
    span.commet-row-label {
        font-style: italic;
    }
    
    span.posted-by {
        color: #09F;
    }
    
    .comment-info {
        font-size: 0.8em;
    }
    .comment-text {
        margin: 10px 0px;
    }
    .btn-reply {
        font-size: 0.8em;
        text-decoration: underline;
        color: #888787;
        cursor:pointer;
    }
    #comment-message {
        margin-left: 20px;
        color: #189a18;
        display: none;
    }
    </style>
    <div class="container col-md-8 col-md-offset-2 mt-5">
        <div class="card">
            <div class="card-header ">
                <h5 class="float-left">{{ $ticket->title }}</h5>
                <div class="clearfix"></div>
            </div>
            <div class="card-body">
                <p> <strong>Status</strong>: {{ $ticket->status ? 'Pending' : 'Answered' }}</p>
                <p> {{ $ticket->content }} </p>
                <a href="{{ action('TicketsController@edit', $ticket->slug) }}" class="btn btn-info float-left mr-2">Edit</a>
                <form method="post" action="{{ action('TicketsController@destroy', $ticket->slug) }}" class="float-left">
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                    <div>
                        <button type="submit" class="btn btn-warning">Delete</button>
                    </div>
                </form>
                <div class="clearfix"></div>
            </div>
        </div>
        @foreach($comments as $comment)
            <div class="card mt-3" >
                <div class="card-body" >
                    {{ $comment->content }}
                    <div id = "delcmt">
                    <form method="post"  class="float-right">
                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        <input type="hidden" name="route_delcmt" value="{{ url("/comment/{$comment->id}/delete")}} " id="route_delcmt">
                            <button type="submit" class="btn btn-warning" id = "del_cmt" >Delete</button>
                    
                    </form>
                </div>
                </div> 
            </div>
        @endforeach
        <div id = "cmt"></div>

        <div class="card mt-3">
        <form method="post" action="{{route('comment')}}">

                @foreach($errors->all() as $error)
                    <p class="alert alert-danger">{{ $error }}</p>
                @endforeach

                @if(session('status'))
                    <div class="alert alert-success">
                        {{ session('status') }}
                    </div>
                @endif

                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <input type="hidden" name="post_id" value="{{ $ticket->id }}">

                <fieldset>
                    <legend class="ml-3">Reply</legend>
                    <div class="form-group">
                        <div class="col-lg-12">
                            <textarea class="form-control" rows="3" id="content" name="content"></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-lg-10 col-lg-offset-2">
                            <button type="reset" class="btn btn-default">Cancel</button>
                            <button type="submit" class="btn btn-primary">Post</button>
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
        {{-- //comment  sử dụng ajax--}}
        <div class="comment-form-container">
            <form id="frm-comment" method="post">
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <input type="hidden" name="route_cmt" value="{{ route('comment') }}" id="route_cmt">
                <input type="hidden" name="route_showcmt" value="{{ url("/ticket/{$ticket->slug}")}} " id="route_showcmt">
                <div class="input-row">
                    <input type="hidden" name="post_id" value="{{ $ticket->id }}" id="post_id">
                     {{-- <input class="input-field"  type="text" name="name" id="name" placeholder="Name" /> --}}
                </div>
                <div class="input-row">
                    <textarea class="form-control" rows="3" id="contentt" name="content"></textarea>
                </div>
                <div>
                    <input type="button" class="btn-submit" id="submitButton"
                        value="Publish" /><div id="comment-message">Comments Added Successfully!</div>
                </div>
    
            </form>
        </div>
    </div id = "#result"></div>
        <div id="output"></div>
               
@endsection
@section('after-scripts')
    <script>
        
        $("#submitButton").click(function () {
               var myItems = new array();
                       $("#comment-message").css('display', 'none');
                    $.ajax({
                        url: $("#route_cmt").val(),
                        data: {post_id : $('#post_id').val(), content : $('#contentt').val()},
                        type: 'post',
                        success: function (response)
                        {  
                            console.log(response);
                            
                            if (response)
                            { 
                                $("#comment-message").css('display', 'inline-block');
                                

                                    myItems.push( "<div class = 'card mt-3'><div class = 'card-body'> " + response['content'] + "</div></div>" );
                                
                                myList.append( myItems.join( "" ) );
                            
                                      
                            } else
                            {
                                alert("Failed to add comments !");
                                return false;
                            }
                        }
                    });
                });
                $("#del_cmt").click(function () {
                    $.ajax({
                        url: $("#route_delcmt").val(),
                        data: {},
                        type: 'post',
                        success: function (response)
                        {  
                           
                            if (response)

                            { 
                                alert('Bạn đã xóa thành công');
                                console.log('ok');
                            }
                        }
                    });
                });
            
               
    </script>
@endsection