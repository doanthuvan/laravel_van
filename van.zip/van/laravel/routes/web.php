<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','PagesController@home')->name('home');
Route::get('/home','PagesController@home');
Route::get('/send_email', 'EmailController@sendEmailReminder');
Route::get('users/login', 'Auth\LoginController@getLogin');
Route::post('users/login', [ 'as' => 'login', 'uses' => 'Auth\LoginController@postLogin']);
Route::get('/contact','PagesController@contact');
Route::get('/about','PagesController@about');
Route::get('/contact', 'TicketsController@create');
Route::post('/contact', 'TicketsController@store');
Route::get('/tickets', 'TicketsController@index');
Route::get('/ticket/{slug?}', 'TicketsController@show');
Route::post('/ticket/{slug?}', 'TicketsController@show');
Route::get('/ticket/{slug?}/edit','TicketsController@edit');
Route::post('/ticket/{slug?}/edit','TicketsController@update');
Route::post('/ticket/{slug?}/delete','TicketsController@destroy');
Route::get('/comment', 'CommentsController@newComment')->name('comment');
Route::post('/comment', 'CommentsController@newComment')->name('comment');
Route::get('users/register', 'Auth\RegisterController@showRegistrationForm');
Route::post('users/register', 'Auth\RegisterController@register');
Route::get('users/logout', [ 'as' => 'logout', 'uses' => 'Auth\LogoutController@getLogout']);

Route::get('my-form','HomeController@myform');
Route::post('my-form','HomeController@myformPost');
Route::post('/comment/{id?}/delete','CommentsController@destroy');
Route::get('/comment/{id?}/delete','CommentsController@destroy')->name('delcomment');

Route::get('/product', 'LiveSearchController@index');
Route::get('/search', 'LiveSearchController@search');
