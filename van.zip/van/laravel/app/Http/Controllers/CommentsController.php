<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\CommentFormRequest;
use App\Comment;

class CommentsController extends Controller
{
    public function newComment(CommentFormRequest $request)
     { 
         
        //  dd($request->get('post_id'));
        $comment = new Comment();
        $comment->content = $request->get('content');
        $comment->post_id = $request->get('post_id');
        $comment->save();
        $arr = [
            "content" => $comment->content,
            "route" => route('delcomment',$comment->id)

        ];

        // return redirect()->back()->with('status', 'Your comment has been created!');
        return  $arr;

    }
    public function destroy($id)
			{
				$comment = Comment::whereId($id)->firstOrFail();
                $comment->delete();
               
			}
}