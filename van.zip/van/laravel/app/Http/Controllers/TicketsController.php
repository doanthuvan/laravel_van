<?php

namespace App\Http\Controllers;
use App\Ticket;
use Illuminate\Http\Request;
use App\Http\Requests\TicketFormRequest;
use Illuminate\Support\Facades\Mail;

use App\Mail\OrderShipped;
use App\Mail\UserEmail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
class TicketsController extends Controller
{
	//
	 public function __construct() {
	 	// $this->middleware('auth');
	 }
    public function create()
		{
		    return view('tickets.created');
		}
		public function store(TicketFormRequest $request)
			{
			    $slug = uniqid();
			    $ticket = new Ticket(array(
				    'title' => $request->get('title'),
				    'content' => $request->get('content'),
				    'slug' => $slug,
				    'content' => $request->get('content'),
			   ));
               
				$ticket->save();
				$data = array(
					'ticket' => $slug,
				);
				// Mail::to('thuvancloud@gmail.com')->send(new UserEmail());
				Mail::send('emails.ticket', $data, function ($message) {
					$message->from('doanthuvan8698@gmail.com', 'Learning Laravel');
				
					$message->to('thuvancloud@gmail.com')->subject('There is a new ticket!');
				});
				return redirect('/contact')->with('status', 'Your ticket has been created! Its unique id is: '.$slug);
				
				
				
				
			}
		public function index()
			{
			    $tickets = Ticket::all();
				return view('tickets.index', compact('tickets'));
			}
		public function show($slug)
			{
				$ticket = Ticket::whereSlug($slug)->firstOrFail();
				
				// var_dump($ticket);
				
				$comments = $ticket->comments()->get();
				// var_dump($comments);
   			 return view('tickets.show', compact('ticket', 'comments'));
			}
		public function edit($slug)
		   {
			    $ticket = Ticket::whereSlug($slug)->firstOrFail();
			    return view('tickets.edit', compact('ticket'));
			}
		public function update($slug, TicketFormRequest $request)
			{
			    $ticket = Ticket::whereSlug($slug)->firstOrFail();
			    $ticket->title = $request->get('title');
			    $ticket->content = $request->get('content');
			    if($request->get('status') != null) {
			        $ticket->status = 0;
			    } else {
			        $ticket->status = 1;
			    }
			    $ticket->save();
			    return redirect(action('TicketsController@edit', $ticket->slug))->with('status', 'The ticket '.$slug.' has been updated!');

			}
			public function destroy($slug)
			{
				$ticket = Ticket::whereSlug($slug)->firstOrFail();
				$comments = $ticket->comments()->delete();
			    $ticket->delete();
			    return redirect('/tickets')->with('status', 'The ticket '.$slug.' has been deleted!');
			}
}
// $ticket = Ticket::with('comments')->get();
				// echo "eager";
				// var_dump($ticket);
   
				// foreach ($ticket as $ticket) {
					
				   
				// 	$comments = $ticket->comments;
				// 	/* You can write loop again  */
				// }