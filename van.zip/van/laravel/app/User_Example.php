<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
class User_example extends Model
{
    public function phone_example(){
        return $this->hasOne('App\Phone_Example');
    }

}
?>