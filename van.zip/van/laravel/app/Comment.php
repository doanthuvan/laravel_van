<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    
    protected $guarded = ['id'];
    // protected $fillable = ['id','post_id','content'];
    //tất cả các cột được gán trừ cột id
    public function ticket()
		{   
		    return $this->belongsTo(Ticket::class);
		}
		
}